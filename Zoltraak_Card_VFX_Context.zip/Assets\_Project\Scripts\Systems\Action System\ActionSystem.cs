using System;
using System.Collections;
using System.Collections.Generic;

[System.Serializable]
public class ActionSystem : Singleton<ActionSystem>
{
    public bool IsPerforming { get; private set; } = false;

    protected override void Awake()
    {
        base.Awake();
        if (DamageOverTimeSystem.Instance == null && GetComponent<DamageOverTimeSystem>() == null)
        {
            gameObject.AddComponent<DamageOverTimeSystem>();
        }
        if (BuffSystem.Instance == null && GetComponent<BuffSystem>() == null)
        {
            gameObject.AddComponent<BuffSystem>();
        }
    }

    private static Dictionary<Type, List<Action<GameAction>>> preSubs = new();
    private static Dictionary<Type, Func<GameAction, IEnumerator>> performers = new();
    private static Dictionary<Type, List<Action<GameAction>>> postSubs = new();

    private static Dictionary<Delegate, Action<GameAction>> delegateMap = new();

    private List<GameAction> reactions = null;

    private void OnDestroy()
    {
        preSubs.Clear();
        performers.Clear();
        postSubs.Clear();
        delegateMap.Clear();
    }

    public static void AttachPerformer<T>(Func<T, IEnumerator> performer) where T : GameAction
    {
        Type type = typeof(T);
        IEnumerator wrappedPerformer(GameAction action) => performer((T)action);

        if 
            (performers.ContainsKey(type)) performers[type] = wrappedPerformer;
        else 
            performers.Add(type, wrappedPerformer);
    }

    public static void DetachPerformer<T>() where T : GameAction
    {
        Type type = typeof(T);

        if (performers.ContainsKey(type))
            performers.Remove(type);
    }

    public static void SubscribeReaction<T>(Action<T> reaction, ReactionTiming timing) where T : GameAction
    {
        Dictionary<Type, List<Action<GameAction>>> subs = timing == ReactionTiming.PRE ? preSubs : postSubs;

        void wrappedReaction(GameAction action) => reaction((T)action);
        delegateMap[reaction] = wrappedReaction;

        if (subs.ContainsKey(typeof(T)))
            subs[typeof(T)].Add(wrappedReaction);
        else
        {
            subs.Add(typeof(T), new());
            subs[typeof(T)].Add(wrappedReaction);
        }
    }

    public static void UnsubscribeReaction<T>(Action<T> reaction, ReactionTiming timing) where T : GameAction
    {
        Dictionary<Type, List<Action<GameAction>>> subs = timing == ReactionTiming.PRE ? preSubs : postSubs;

        if (subs.ContainsKey(typeof(T)) && delegateMap.TryGetValue(reaction, out var wrappedReaction))
        {
            subs[typeof(T)].Remove(wrappedReaction);
            delegateMap.Remove(reaction);
        }
    }

    public bool Perform(GameAction action, Action OnPerformFinished = null)
    {
        if (IsPerforming) return false;

        IsPerforming = true;

        StartCoroutine(Flow(action, () =>
        {
            IsPerforming = false;
            OnPerformFinished?.Invoke();
        }));

        return true;
    }

    public void AddReaction(GameAction gameAction)
    {
        reactions?.Add(gameAction);
    }

    private IEnumerator Flow(GameAction action, Action OnFlowFinished = null)
    {
        reactions = action.PreReactions;
        PerformSubscribers(action, preSubs);
        yield return PerformReactions();

        reactions = action.PerformReactions;
        yield return PerformPerformer(action);
        yield return PerformReactions();

        reactions = action.PostReactions;
        PerformSubscribers(action, postSubs);
        yield return PerformReactions();

        OnFlowFinished?.Invoke();
    }

    private IEnumerator PerformPerformer(GameAction action)
    {
        Type type = action.GetType();

        if (performers.ContainsKey(type))
            yield return performers[type](action);
    }

    private IEnumerator PerformReactions()
    {
        foreach (GameAction reaction in reactions)
        {
            yield return Flow(reaction);
        }
    }

    private void PerformSubscribers(GameAction action, Dictionary<Type, List<Action<GameAction>>> subs)
    {
        Type type = action.GetType();
        
        if (subs.ContainsKey(type))
        {
            foreach (Action<GameAction> sub in subs[type])
            {
                sub(action);
            }
        }
    }
}